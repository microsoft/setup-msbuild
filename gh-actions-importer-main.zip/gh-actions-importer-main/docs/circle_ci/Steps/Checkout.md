# Run

## CircleCI Input

```yaml
steps:
- checkout
```

### Transformed Github Action

```yaml
- uses: actions/checkout@v2
```

### Unsupported Options

- None
