# [CircleCI AwsS3](https://circleci.com/developer/orbs/orb/circleci/aws-s3)

| CircleCI                                                            | GitHub                                                                         |
| :------------------------------------------------------------------ | :----------------------------------------------------------------------------- |
| [Copy](Copy.md)                                                     | aws-actions/configure-aws-credentials@v1, run                                  |
| [Sync](Sync.md)                                                     | aws-actions/configure-aws-credentials@v1, run                                  |
