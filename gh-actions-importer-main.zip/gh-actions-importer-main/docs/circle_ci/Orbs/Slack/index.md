# [CircleCI Slack](https://circleci.com/developer/orbs/orb/circleci/slack)

| CircleCI                                                            | GitHub                                        |
| :------------------------------------------------------------------ | :-------------------------------------------- |
| [Notify](Notify.md)                                                 | rtCamp/action-slack-notify@v2.2.0                 |
| [OnHold](OnHold.md)                                                 | rtCamp/action-slack-notify@v2.2.0, environment    |

## Unsupported

- None
