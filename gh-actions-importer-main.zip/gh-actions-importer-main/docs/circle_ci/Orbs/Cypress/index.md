# [CypressIO Cypress](https://circleci.com/developer/orbs/orb/cypress-io/cypress)

| CircleCI                                                            | GitHub                                              |
| :------------------------------------------------------------------ | :-------------------------------------------------- |
| [Executors](Executors.md)                                           | container                                           |
| [Install](Install.md)                                               | actions/cache@v2, run                               |
| [Run](Run.md)                                                       | cypress-io/github-action@v2                         |
| [Setup](Setup.md)                                                   | actions/cache@v2, run                               |
| [WriteWorkspace](WriteWorkspace.md)                                 | actions/upload-artifact@v2                          |

## Unsupported

- None
