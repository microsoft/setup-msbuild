# [CircleCI AwsCli](https://circleci.com/developer/orbs/orb/circleci/aws-cli)

| CircleCI                                                            | GitHub                                        |
| :------------------------------------------------------------------ | :-------------------------------------------- |
| [Default](Default.md)                                               | container                                     |
| [Setup](Setup.md)                                                   | aws-actions/configure-aws-credentials@v1      |

## Indeterminate behavior on self-hosted runners

- install
