# Srcclr

## Travis Input

```yaml
srcclr: true
```

### Transformed Github Action

```yaml
- run: curl -sSL https://srcclr.com/install | sh
```
