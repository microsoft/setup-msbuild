# Cache

- [Bundler](Cache/Bundler.md)
- [Cargo](Cache/Cargo.md)
- [Ccache](Cache/Ccache.md)
- [Cocoapods](Cache/Cocoapods.md)
- [Directories](Cache/Directories.md)
- [Npm](Cache/Npm.md)
- [Packages](Cache/Packages.md)
- [Pip](Cache/Pip.md)
- [Yarn](Cache/Yarn.md)

Any cache steps not listed above will not be mapped to an action.

## Unsupported

- branch
- edge
- timeout
- apt
