# Lein

## Travis Input

```yaml
lein: 2.1
```

## Transformed Github Action

```yaml
- uses: DeLaGuardo/setup-clojure@9.5
  with:
    lein: 2.9.1
```
