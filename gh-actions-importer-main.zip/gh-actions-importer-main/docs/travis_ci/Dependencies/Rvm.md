# RVM

## Travis Input

```yaml
rvm: 2.5
```

## Transformed Github Action

```yaml
- uses: ruby/setup-ruby@v1.138.0
  with:
    ruby-version: head
```
