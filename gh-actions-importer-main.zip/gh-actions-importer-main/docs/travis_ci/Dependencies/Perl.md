# Perl

## Travis Input

```yaml
perl: 5.43
```

## Transformed Github Action

```yaml
- uses: shogo82148/actions-setup-perl@v1.20.1
  with:
    perl-version: '5.43'
```
