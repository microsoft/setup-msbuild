# Matlab

## Travis Input

```yaml
matlab: latest
```

## Transformed Github Action

```yaml
- uses: matlab-actions/setup-matlab@v1.2.3
  with:
    release: latest
```
