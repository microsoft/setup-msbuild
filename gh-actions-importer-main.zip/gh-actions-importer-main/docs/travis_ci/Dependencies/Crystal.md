# Crystal

## Travis Input

```yaml
crystal: latest
```

## Transformed Github Action

```yaml
- uses: oprypin/install-crystal@v1.7.0
  with:
    crystal: latest
```
