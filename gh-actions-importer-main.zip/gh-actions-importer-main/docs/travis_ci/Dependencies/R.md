# R

## Travis Input

```yaml
r: 3.5.3
```

## Transformed Github Action

```yaml
- uses: r-lib/actions/setup-r@v2
  with:
    r-version: 3.5.3
```
