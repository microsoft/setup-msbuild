# Pandoc Version

## Travis Input

```yaml
pandoc_version: 2.7.3
```

## Transformed Github Action

```yaml
- uses: r-lib/actions/setup-pandoc@v1
  with:
    pandoc-version: 2.7.4
```
