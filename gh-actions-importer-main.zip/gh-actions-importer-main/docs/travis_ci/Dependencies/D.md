# D

## Travis Input

```yaml
d: dmd-2.089.1
```

## Transformed Github Action

```yaml
- uses: dlang-community/setup-dlang@v1.3.0
  with:
    compiler: dmd-2.089.1
```
