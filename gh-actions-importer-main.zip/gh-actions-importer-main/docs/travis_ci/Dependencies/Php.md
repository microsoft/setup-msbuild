# Php

## Travis Input

```yaml
php: 7.4
```

## Transformed Github Action

```yaml
- uses: shivammathur/setup-php@2.24.0
  with:
    tools: phpunit
    php-version: '7.4'
```
