# Ghc

## Travis Input

```yaml
ghc: 8.6.4
```

## Transformed Github Action

```yaml
- uses: haskell/actions/setup@v2.3.3
  with:
    ghc-version: '8.6.4'
```
