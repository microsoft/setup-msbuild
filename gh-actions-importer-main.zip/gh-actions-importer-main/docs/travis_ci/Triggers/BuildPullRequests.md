# Build Pull Requests

## Travis Input

```json
{
  "settings": {
    "build_pull_requests": true
  }
}
```

### Transformed Github Action

```yaml
  pull_request:
```
