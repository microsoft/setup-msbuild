# Postgresql

## Travis Input

```yaml
services:
  - postgresql
```

## Transformed Github Action

```yaml
services: 
  postgresql:
    image: postgres
```

### Unsupported Options

- None
