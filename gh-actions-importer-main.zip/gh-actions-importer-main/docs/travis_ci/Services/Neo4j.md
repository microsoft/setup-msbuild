# Neo4j

## Travis Input

```yaml
services:
  - neo4j
```

## Transformed Github Action

```yaml
services: 
  neo4j:
    image: neo4j
```

### Unsupported Options

- None
