# Mysql

## Travis Input

```yaml
services:
  - mysql
```

## Transformed Github Action

```yaml
services: 
  mysql:
    image: mysql
```

### Unsupported Options

- None
