# Couchdb

## Travis Input

```yaml
services:
  - couchdb
```

## Transformed Github Action

```yaml
services: 
  couchdb:
    image: couchdb
```

### Unsupported Options

- None
