# Elasticsearch

## Travis Input

```yaml
services:
  - elasticsearch
```

## Transformed Github Action

```yaml
services: 
  elasticsearch:
    image: elasticsearch:6.5.0
```

### Unsupported Options

- None
