# Cassandra

## Travis Input

```yaml
services:
  - cassandra
```

## Transformed Github Action

```yaml
services: 
  cassandra:
    image: cassandra
```

### Unsupported Options

- None
