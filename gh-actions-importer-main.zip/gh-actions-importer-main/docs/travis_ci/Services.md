# Services

- [Postgresql](Services/Postgresql.md)

## Unsupported

- cassandra
- couchdb
- elasticsearch
- memcached
- mongodb
- mysql
- neo4j
- rabbitmq
- redis
- docker
- riak
- xvfb
