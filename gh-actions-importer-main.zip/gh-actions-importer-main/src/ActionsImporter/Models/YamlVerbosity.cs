﻿namespace ActionsImporter.Models;

public enum YamlVerbosity
{
    info,
    minimal,
    quiet
}
