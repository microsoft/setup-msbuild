﻿namespace ActionsImporter.Models;

public enum Provider
{
    GitHub,
    AzureDevOps,
    CircleCI,
    GitLabCI,
    Jenkins,
    TravisCI,
    Bamboo
}
