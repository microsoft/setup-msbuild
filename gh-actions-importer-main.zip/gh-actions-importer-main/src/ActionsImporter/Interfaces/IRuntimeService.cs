﻿namespace ActionsImporter.Interfaces;

public interface IRuntimeService
{
    bool IsLinux { get; }
}
